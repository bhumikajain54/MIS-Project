import { Component } from '@angular/core';

@Component({
  selector: 'app-my-reports',
  templateUrl: './my-reports.component.html',
  styleUrl: './my-reports.component.scss'
})
export class MyReportsComponent {

}
