import { Component } from '@angular/core';

@Component({
  selector: 'app-my-policy-claim',
  templateUrl: './my-policy-claim.component.html',
  styleUrl: './my-policy-claim.component.scss'
})
export class MyPolicyClaimComponent {

}
