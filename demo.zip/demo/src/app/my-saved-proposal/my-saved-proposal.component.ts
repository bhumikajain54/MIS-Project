import { Component } from '@angular/core';

@Component({
  selector: 'app-my-saved-proposal',
  templateUrl: './my-saved-proposal.component.html',
  styleUrl: './my-saved-proposal.component.scss'
})
export class MySavedProposalComponent {

}
