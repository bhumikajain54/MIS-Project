import { Component } from '@angular/core';

@Component({
  selector: 'app-my-renewals',
  templateUrl: './my-renewals.component.html',
  styleUrl: './my-renewals.component.scss'
})
export class MyRenewalsComponent {

}
