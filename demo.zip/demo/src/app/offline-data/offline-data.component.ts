import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-offline-data',
  templateUrl: './offline-data.component.html',
  styleUrl: './offline-data.component.scss'
})
export class OfflineDataComponent {
  
}
