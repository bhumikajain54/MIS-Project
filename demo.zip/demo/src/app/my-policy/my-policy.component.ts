import { Component } from '@angular/core';

@Component({
  selector: 'app-my-policy',
  templateUrl: './my-policy.component.html',
  styleUrl: './my-policy.component.scss'
})
export class MyPolicyComponent {

}
