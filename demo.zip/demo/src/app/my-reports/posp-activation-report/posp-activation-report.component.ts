import { Component } from '@angular/core';

@Component({
  selector: 'app-posp-activation-report',
  templateUrl: './posp-activation-report.component.html',
  styleUrl: './posp-activation-report.component.scss'
})
export class POSPActivationReportComponent {

}
