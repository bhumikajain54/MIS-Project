import { Component } from '@angular/core';

@Component({
  selector: 'app-my-quotation',
  templateUrl: './my-quotation.component.html',
  styleUrl: './my-quotation.component.scss'
})
export class MyQuotationComponent {

}
