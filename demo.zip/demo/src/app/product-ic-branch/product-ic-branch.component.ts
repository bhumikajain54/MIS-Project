import { Component } from '@angular/core';

@Component({
  selector: 'app-product-ic-branch',
  templateUrl: './product-ic-branch.component.html',
  styleUrl: './product-ic-branch.component.scss'
})
export class ProductIcBranchComponent {

}
