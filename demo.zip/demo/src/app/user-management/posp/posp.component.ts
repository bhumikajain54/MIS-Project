import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-posp',
  templateUrl: './posp.component.html',
  styleUrl: './posp.component.scss'
})
export class POSPComponent {
  userForm!: FormGroup;
  roles: any;
  showSidebar = true;
  searchKeyword: string = '';
    users = [
        { name: 'Muzffar Hussain', mobile: '9199321155', role: 'POSP', status: 'Active', lastUpdated: new Date('2024-10-10T12:41:00') },
        { name: 'MOHAMMAD ZAMEER AHMAD MUKHDOOMI', mobile: '9419046674', role: 'POSP', status: 'Active', lastUpdated: new Date('2024-09-11T13:24:00') },
        { name: 'Javaid Ahmad Punjra', mobile: '9103806778', role: 'POSP', status: 'Active', lastUpdated: new Date('2024-08-30T18:09:00') },
        { name: 'Gaurav Raghav', mobile: '7252979097', role: 'POSP', status: 'Active', lastUpdated: new Date('2024-08-17T16:14:00') }
    ];

    filteredUsers = [...this.users];
    username: string = 'bimaakawach';

    searchUser() {
        this.filteredUsers = this.users.filter(user =>
            user.name.toLowerCase().includes(this.searchKeyword.toLowerCase()) ||
            user.mobile.includes(this.searchKeyword)
        );
    }

    resetSearch() {
        this.filteredUsers = [...this.users];
        this.searchKeyword = '';
    }
  constructor(private router: Router,private fb: FormBuilder) {}
  redirectToProductICBranchViewAll() {
    this.router.navigateByUrl('/product-ic-branch/view-all-product-ic-branch')
  }
  redirectToMySavedProposalViewAll() {
    this.router.navigateByUrl('/my-saved-proposal/view-all-saved-proposal')
  }
  redirectToUserManagementPOSP() {
    this.router.navigateByUrl('/user-management/posp')
  }
  redirectToUserManagementViewAll() {
    this.router.navigateByUrl('/user-management/view-all-user-management')
  }
  redirectToUserManagementAddNew() {
    this.router.navigateByUrl('/user-management/add-new-user-management')
  }
  redirectToMyPolicyClaimViewAll() {
    this.router.navigateByUrl('/my-policy-claim/view-all-policy-claim')
  }
  redirectToMyPolicyClaimAddNew() {
    this.router.navigateByUrl('/my-policy-claim/add-new-policy-claim')
  }
  redirectToMyReportsViewAll() {
    this.router.navigateByUrl('/my-reports/posp-activation-report')
  }
  redirectToMyRenewalsViewAll() {
    this.router.navigateByUrl('/my-renewals/view-all-renewals')
  }
  redirectToMyQuotationViewAll() {
    this.router.navigateByUrl('/my-quotation/view-all-quotation')
  }
  redirectToMyPolicyViewAll() {
    this.router.navigateByUrl('/my-policy/view-all-policy')
  }
  redirectToAddOtherOffline() {
    this.router.navigateByUrl('/offline-data/add-other-offline')
  }
  redirectToAddHealth() {
    this.router.navigateByUrl('/offline-data/add-health')
  }
  redirectToAddNew() {
    this.router.navigateByUrl('/offline-data/add-new')
  }
  redirectToViewAll() {
    this.router.navigateByUrl('/offline-data/view-all')
  }
}
